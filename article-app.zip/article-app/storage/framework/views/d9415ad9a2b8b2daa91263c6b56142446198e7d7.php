
<?php $__env->startSection('container'); ?>
    <h4>Halaman About</h4>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Laravel\article-app\resources\views/home/about/index.blade.php ENDPATH**/ ?>