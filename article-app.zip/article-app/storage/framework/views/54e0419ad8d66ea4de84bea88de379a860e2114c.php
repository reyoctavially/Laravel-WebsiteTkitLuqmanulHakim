

<?php $__env->startSection('container'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h4>Data Info Registrasi</h4>
    </div>

    <?php if(session()->has('success')): ?>
      <div class="alert alert-success alert-dismissible fade show col-lg-10" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    <?php endif; ?>

    <div class="table-responsive col-lg-10 mb-3">
      
        <table class="table table-stripped" id="registrations">
          <thead>
            <tr>
              <th></th>
              <th scope="col">#</th>
              <th scope="col">Info Registrasi</th>
              <th scope="col">Aksi</th>
            </tr>
          </thead>
          <tbody>
              <?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                <tr data-child-value="<b>Keterangan:</b> </br> <?php echo e($registration->excerpt); ?>">
                    <td class="dt-control"></td>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($registration->title); ?></td>
                    <td>
                        <a href="/dashboard/registrations/<?php echo e($registration->slug); ?>" class="badge bg-info"><span data-feather="eye"></span></a>
                        <a href="/dashboard/registrations/<?php echo e($registration->slug); ?>/edit" class="badge bg-warning"><span data-feather="edit"></span></a>
                        
                    </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      
      
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
      
      <script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.11.5/datatables.min.js"></script>
      <script>
        function format(value) {
          return '<div>' + value + '</div>';
        }

        $(document).ready( function () {
          var table = $('#registrations').DataTable();
          $('#registrations tbody').on('click', 'td.dt-control', function () {
          var tr = $(this).closest('tr');
          var row = table.row( tr );

          if ( row.child.isShown() ) {
                // This row is already open - close it
                row.child.hide();
                tr.removeClass('shown');
            }
            else {
                // Open this row
                row.child(format(tr.data('child-value'))).show();
                tr.addClass('shown');
            }
        });
        });
      </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Laravel\article-app\resources\views/dashboard/registrations/index.blade.php ENDPATH**/ ?>