

<?php $__env->startSection('container'); ?>
    <div class="container">
        <div class="row my-3">
            <div class="col-lg-8">
                <h4 class="mb-3"><?php echo e($allpost->title); ?></h4>
                <p>oleh <b><?php echo e($allpost->author->name); ?></b> di <b><?php echo e($allpost->category->name); ?></b></p>
                <a href="/dashboard/allposts" class="btn btn-success"><span data-feather="arrow-left"></span> Semua Postingan</a>
                <a href="/dashboard/allposts/destroy/<?php echo e($allpost->slug); ?>" class="btn btn-danger" onclick="return confirm('Apakah anda yakin akan menghapus postingan <?php echo e($allpost->title); ?>?')"><span data-feather="x-circle"></span> Hapus</a>
                <?php if($allpost->image): ?>
                    <div>
                        <img src="<?php echo e(asset('img/post-images/' . $allpost->image)); ?>" class="img-fluid mt-3">
                    </div>
                <?php else: ?>
                    <img src="<?php echo e(asset('img/post-images/' . $image)); ?>" class="img-fluid mt-3">
                <?php endif; ?>
                <article class="my-3">
                    <?php echo $allpost->body; ?>

                </article>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Laravel\article-app\resources\views/dashboard/allposts/show.blade.php ENDPATH**/ ?>