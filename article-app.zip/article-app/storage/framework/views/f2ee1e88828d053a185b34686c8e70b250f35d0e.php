

<?php $__env->startSection('container'); ?>
    <main id="main" data-aos="fade-up">
         <!-- ======= Breadcrumbs Section ======= -->
        <section class="breadcrumbs">
            <div class="container">
    
            <div class="d-flex justify-content-between align-items-center">
                <ol>
                <li><a href="/">Beranda</a></li>
                <li><a href="/home/posts">Informasi</a></li>
                <li>Rincian Informasi</li>
                </ol>
            </div>
    
            </div>
        </section><!-- Breadcrumbs Section -->

        <div class="container mt-3">
            <div class="row justify-content-center mb-5">
                <div class="col-md-8 shadow p-3 mb-5 bg-white rounded border">
                    <h4 style="color: orange"><?php echo e($post->title); ?></h4>
                    <p>oleh <a href="/home/posts?author=<?php echo e($post->author->username); ?>" class="text-decoration-none"><?php echo e($post->author->name); ?></a> di <a href="/home/posts?category=<?php echo e($post->category->slug); ?>" class="text-decoration-none"><?php echo e($post->category->name); ?></a></p>
                    <?php if($post->image): ?>
                        <center>
                            <img src="<?php echo e(asset('img/post-images/' . $post->image)); ?>" alt="<?php echo e($post->category->name); ?>" class="img-fluid rounded">
                        </center>
                    <?php else: ?>
                        <center>
                            <img src="<?php echo e(asset('img/post-images/' . $image)); ?>" class="card-img-top rounded">
                        </center>
                    <?php endif; ?>
                    <article class="my-3">
                        <?php echo $post->body; ?>

                    </article>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Laravel\article-app\resources\views/home/posts/show.blade.php ENDPATH**/ ?>