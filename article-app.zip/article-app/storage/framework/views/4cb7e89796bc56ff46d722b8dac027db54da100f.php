

<?php $__env->startSection('container'); ?>
    <div class="container">
        <div class="row my-3">
            <div class="col-lg-8">
                <a href="/dashboard/testimonials" class="btn btn-success"><span data-feather="arrow-left"></span> Semua Testimoni</a>
                <a href="/dashboard/testimonials/<?php echo e($testimonial->id); ?>/edit" class="btn btn-warning"><span data-feather="edit"></span> Edit</a>
                <form action="/dashboard/testimonials/<?php echo e($testimonial->id); ?>" method="POST" class="d-inline">
                    <?php echo method_field('delete'); ?>
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-danger" onclick="return confirm('Apakah anda yakin akan menghapus testimoni dari <?php echo e($testimonial->name); ?>?')"><span data-feather="x-circle"></span> Hapus</button>
                </form>
                <div class="text-center m-3 border p-3">
                    <?php if($testimonial->image): ?>
                        <img src="<?php echo e(asset('storage/' . $testimonial->image)); ?>" width="200" class="img-thumbnail rounded-circle">
                    <?php else: ?>
                        <img src="<?php echo e(asset('storage/testimonial-images/' . $image)); ?>" width="200" class="img-thumbnail rounded-circle">
                    <?php endif; ?>
                    <h5 class="mt-3"><?php echo e($testimonial->name); ?></h5>
                    <h6 class="text-muted"><?php echo e($testimonial->status); ?></h6>
                    <p class="text-muted"><?php echo $testimonial->body; ?></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Laravel\article-app\resources\views/dashboard/testimonials/show.blade.php ENDPATH**/ ?>