

<?php $__env->startSection('container'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h4>Edit Profil Sekolah</h4>
    </div>   
    
    <div class="col-lg-8">
        <form action="/dashboard/profiles/<?php echo e($profile->id); ?>" method="POST" class="mb-5" enctype="multipart/form-data">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>

            <div class="mb-3 border p-2">
                <label for="image_satu" class="form-label">Foto Profil Satu</label>
                <input type="hidden" name="oldImage" value="<?php echo e($profile->image_satu); ?>">
                <?php if($profile->image_satu): ?>
                    <img src="<?php echo e(asset('img/profile-images/' . $profile->image_satu)); ?>" class="img-preview-satu img-fluid m-3 col-sm-5 d-block">
                <?php else: ?>
                    <img class="img-preview-satu img-fluid m-3 col-sm-5">
                <?php endif; ?>
                <input class="form-control <?php $__errorArgs = ['image_satu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="image_satu" name="image_satu" onchange="previewImageSatu()">
                <?php $__errorArgs = ['image_satu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3 border p-2">
                <label for="image_dua" class="form-label">Foto Profil Dua</label>
                <input type="hidden" name="oldImage" value="<?php echo e($profile->image_dua); ?>">
                <?php if($profile->image_dua): ?>
                    <img src="<?php echo e(asset('img/profile-images/' . $profile->image_dua)); ?>" class="img-preview-dua img-fluid m-3 col-sm-5 d-block">
                <?php else: ?>
                    <img class="img-preview-dua img-fluid m-3 col-sm-5">
                <?php endif; ?>
                <input class="form-control <?php $__errorArgs = ['image_dua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="image_dua" name="image_dua" onchange="previewImageDua()">
                <?php $__errorArgs = ['image_dua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3 border p-2">
                <label for="image_tiga" class="form-label">Foto Profil Tiga</label>
                <input type="hidden" name="oldImage" value="<?php echo e($profile->image_tiga); ?>">
                <?php if($profile->image_tiga): ?>
                    <img src="<?php echo e(asset('img/profile-images/' . $profile->image_tiga)); ?>" class="img-preview-tiga img-fluid m-3 col-sm-5 d-block">
                <?php else: ?>
                    <img class="img-preview-tiga img-fluid m-3 col-sm-5">
                <?php endif; ?>
                <input class="form-control <?php $__errorArgs = ['image_tiga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="image_tiga" name="image_tiga" onchange="previewImageTiga()">
                <?php $__errorArgs = ['image_tiga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3">
                <label for="visi" class="form-label">Visi Sekolah</label>
                <input id="visi" type="hidden" name="visi" value="<?php echo e(old('visi', $profile->visi)); ?>">
                <trix-editor input="visi"></trix-editor>
                <?php $__errorArgs = ['visi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small><p class="text-danger"><?php echo e($message); ?></p></small>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
                <label for="misi" class="form-label">Misi Sekolah</label>
                <input id="misi" type="hidden" name="misi" value="<?php echo e(old('misi', $profile->misi)); ?>">
                <trix-editor input="misi"></trix-editor>
                <?php $__errorArgs = ['misi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small><p class="text-danger"><?php echo e($message); ?></p></small>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
                <label for="profil" class="form-label">Profil Singkat</label>
                <input id="profil" type="hidden" name="profil" value="<?php echo e(old('profil', $profile->profil)); ?>">
                <trix-editor input="profil"></trix-editor>
                <?php $__errorArgs = ['profil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small><p class="text-danger"><?php echo e($message); ?></p></small>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
                <label for="sejarah" class="form-label">Sejarah Singkat</label>
                <input id="sejarah" type="hidden" name="sejarah" value="<?php echo e(old('sejarah', $profile->sejarah)); ?>">
                <trix-editor input="sejarah"></trix-editor>
                <?php $__errorArgs = ['sejarah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small><p class="text-danger"><?php echo e($message); ?></p></small>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
                <label for="alamat" class="form-label">Alamat</label>
                <input id="alamat" type="hidden" name="alamat" value="<?php echo e(old('alamat', $profile->alamat)); ?>">
                <trix-editor input="alamat"></trix-editor>
                <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small><p class="text-danger"><?php echo e($message); ?></p></small>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="input-group mb-3">
                <span class="input-group-text" id="telp">Telepon</span>
                <input type="text" class="form-control" name="telp" value="<?php echo e(old('telp', $profile->telp)); ?>">
                <?php $__errorArgs = ['telp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small><p class="text-danger"><?php echo e($message); ?></p></small>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="input-group mb-3">
                <span class="input-group-text" id="email"> Email</span>
                <input type="text" class="form-control" name="email" value="<?php echo e(old('email', $profile->email)); ?>">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small><p class="text-danger"><?php echo e($message); ?></p></small>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="input-group mb-3">
                <span class="input-group-text" id="link_facebook"> Facebook</span>
                <input type="text" class="form-control" name="link_facebook" value="<?php echo e(old('link_facebook', $profile->link_facebook)); ?>">
                <?php $__errorArgs = ['link_facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small><p class="text-danger"><?php echo e($message); ?></p></small>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="input-group mb-3">
                <span class="input-group-text" id="whatsapp"> Whatsapp (Nomor)</span>
                <input type="number" class="form-control" name="whatsapp" value="<?php echo e(old('whatsapp', $profile->whatsapp)); ?>">
                <?php $__errorArgs = ['whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small><p class="text-danger"><?php echo e($message); ?></p></small>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="input-group mb-3">
                <span class="input-group-text" id="link_whatsapp"> Whatsapp (Link)</span>
                <input type="text" class="form-control" name="link_whatsapp" value="<?php echo e(old('link_whatsapp', $profile->link_whatsapp)); ?>">
                <?php $__errorArgs = ['link_whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small><p class="text-danger"><?php echo e($message); ?></p></small>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="input-group mb-3">
                <span class="input-group-text" id="link_instagram"> Instagram</span>
                <input type="text" class="form-control" name="link_instagram" value="<?php echo e(old('link_instagram', $profile->link_instagram)); ?>">
                <?php $__errorArgs = ['link_instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small><p class="text-danger"><?php echo e($message); ?></p></small>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="input-group mb-3">
                <span class="input-group-text" id="link_youtube"> Youtube (Channel)</span>
                <input type="text" class="form-control" name="link_youtube" value="<?php echo e(old('link_youtube', $profile->link_youtube)); ?>">
                <?php $__errorArgs = ['link_youtube'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small><p class="text-danger"><?php echo e($message); ?></p></small>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="input-group mb-3">
                <span class="input-group-text" id="link_embed"> Youtube (Video)</span>
                <input type="text" class="form-control" name="link_embed" value="<?php echo e(old('link_embed', $profile->link_embed)); ?>">
                <?php $__errorArgs = ['link_embed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small><p class="text-danger"><?php echo e($message); ?></p></small>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="btn btn-primary">Perbarui Profil</button>
        </form>
    </div>
    <script>
        function previewImageSatu(){
            const image = document.querySelector('#image_satu');
            const imgPreview = document.querySelector('.img-preview-satu');

            imgPreview.style.display = 'block';

            const oFReader = new FileReader();
            oFReader.readAsDataURL(image.files[0]);
            
            oFReader.onload = function(oFREvent){
                imgPreview.src = oFREvent.target.result;
            }
        }
        function previewImageDua(){
            const image = document.querySelector('#image_dua');
            const imgPreview = document.querySelector('.img-preview-dua');

            imgPreview.style.display = 'block';

            const oFReader = new FileReader();
            oFReader.readAsDataURL(image.files[0]);
            
            oFReader.onload = function(oFREvent){
                imgPreview.src = oFREvent.target.result;
            }
        }
        function previewImageTiga(){
            const image = document.querySelector('#image_tiga');
            const imgPreview = document.querySelector('.img-preview-tiga');

            imgPreview.style.display = 'block';

            const oFReader = new FileReader();
            oFReader.readAsDataURL(image.files[0]);
            
            oFReader.onload = function(oFREvent){
                imgPreview.src = oFREvent.target.result;
            }
        }
        document.addEventListener('trix-file-accept', function(e){
            e.preventDefault();
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Laravel\article-app\resources\views/dashboard/profiles/edit.blade.php ENDPATH**/ ?>