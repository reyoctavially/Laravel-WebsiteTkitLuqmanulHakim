

<?php $__env->startSection('container'); ?>
    <section id="featured-services" class="featured-services">
        <div class="container" data-aos="fade-up">
            <div class="section-title">
                <img src="/img/akhi.png" style="max-height: 100px;">
                <h2>Program Unggulan</h2>
                <img src="/img/ukhti.png" style="max-height: 100px;">
                <h3>Cari Tahu <span>Program Unggulan</span></h3>
                <p>Program Unggulan Taman Kanak-Kanak Islam Terpadu Luqmanul Hakim.</p>
            </div>
            <div class="row">
                <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 mb-3">
                        <div class="card h-100 shadow p-1 mb-5 bg-white rounded" data-aos="fade-up" data-aos-delay="100">
                            <?php if($program->image): ?>
                                <img src="<?php echo e(asset('img/program-images/' . $program->image)); ?>" class="img-fluid rounded">
                            <?php else: ?>
                                <img src="<?php echo e(asset('img/program-images/' . $image)); ?>" class="card-img-top rounded">
                            <?php endif; ?>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($program->title); ?></h5>
                                <p class="card-text"><?php echo e($program->excerpt); ?></p>
                                <a href="/home/programs/<?php echo e($program->slug); ?>" class="text-decoration-none btn btn-primary">Selengkapnya</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="d-flex justify-content-center">
                <?php echo e($programs->links()); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Laravel\article-app\resources\views/home/programs/index.blade.php ENDPATH**/ ?>