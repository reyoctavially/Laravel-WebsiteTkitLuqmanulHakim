

<?php $__env->startSection('container'); ?>
    <main id="main" data-aos="fade-up">
        <!-- ======= Breadcrumbs Section ======= -->
        <section class="breadcrumbs">
            <div class="container">
    
            <div class="d-flex justify-content-between align-items-center">
                <ol>
                <li><a href="/">Beranda</a></li>
                <li><a href="/home/programs">Program Unggulan</a></li>
                <li>Rincian Program Unggulan</li>
                </ol>
            </div>
    
            </div>
        </section><!-- Breadcrumbs Section -->
        <div class="container mt-3">
            <div class="row justify-content-center mb-5">
                <div class="col-md-8 shadow p-3 mb-5 bg-white rounded border">
                    <h4 class="text-center mb-3" style="color: orange"><?php echo e($program->title); ?></h4>
                        <?php if($program->image): ?>
                            <center>
                                <img src="<?php echo e(asset('img/program-images/' . $program->image)); ?>" class="img-fluid rounded">
                            </center>
                        <?php else: ?>
                            <center>
                                <img src="<?php echo e(asset('img/program-images/' . $image)); ?>" class="card-img-top rounded">
                            </center>
                        <?php endif; ?>
                        <article class="my-3">
                            <?php echo $program->body; ?>

                        </article>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Laravel\article-app\resources\views/home/programs/show.blade.php ENDPATH**/ ?>