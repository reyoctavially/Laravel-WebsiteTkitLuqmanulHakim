

<?php $__env->startSection('container'); ?>
    <div class="container">
        <div class="row my-3">
            <div class="col-lg-8">
                <a href="/dashboard/users" class="btn btn-success"><span data-feather="arrow-left"></span> Semua Data Guru</a>
                <a href="/dashboard/users/<?php echo e($user->id); ?>/edit" class="btn btn-warning"><span data-feather="edit"></span> Edit</a>
                <form action="/dashboard/users/<?php echo e($user->id); ?>" method="POST" class="d-inline">
                    <?php echo method_field('delete'); ?>
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-danger" onclick="return confirm('Apakah anda yakin akan menghapus <?php echo e($user->name); ?>? Pastikan terlebih dahulu semua postingan milik <?php echo e($user->name); ?> sudah terhapus.')"><span data-feather="x-circle"></span> Hapus</button>
                </form>
                <div class="text-center m-3 border p-3">
                    <?php if($user->image): ?>
                        <img src="<?php echo e(asset('img/user-images/' . $user->image)); ?>" class="img-thumbnail rounded-circle" style="
                        width: 200px;
                        height: 200px;
                        object-fit: cover;
                        border-radius: 100%;
                        border: 6px solid rgba(255, 255, 255, 0.15);
                        margin: 0 auto;border-radius: 100%;">
                    <?php else: ?>
                        <img src="<?php echo e(asset('img/user-images/' . $image)); ?>" class="img-thumbnail rounded-circle" style="
                        width: 200px;
                        height: 200px;
                        object-fit: cover;
                        border-radius: 100%;
                        border: 6px solid rgba(255, 255, 255, 0.15);
                        margin: 0 auto;border-radius: 100%;">
                    <?php endif; ?>
                    <h5 class="mt-3"><?php echo e($user->name); ?></h5>
                    <h6 class="text-muted"><?php echo e($user->email); ?></h6>
                    <p class="text-muted"><?php echo e($user->position); ?></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Laravel\article-app\resources\views/dashboard/users/show.blade.php ENDPATH**/ ?>