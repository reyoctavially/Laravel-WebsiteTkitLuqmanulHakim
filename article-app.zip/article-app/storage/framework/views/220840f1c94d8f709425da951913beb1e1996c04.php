

<?php $__env->startSection('container'); ?>
    <div class="container mt-3">
        <div class="row justify-content-center mb-5">
            <div class="col-md-8">
                <h4><?php echo e($post->title); ?></h4>
                <p>oleh <a href="/?author=<?php echo e($post->author->username); ?>" class="text-decoration-none"><?php echo e($post->author->name); ?></a> di <a href="/?category=<?php echo e($post->category->slug); ?>" class="text-decoration-none"><?php echo e($post->category->name); ?></a></p>
                <?php if($post->image): ?>
                    <img src="<?php echo e(asset('storage/' . $post->image)); ?>" alt="<?php echo e($post->category->name); ?>" class="img-fluid">
                <?php else: ?>
                    <img src="<?php echo e(asset('storage/post-images/' . $image)); ?>" class="card-img-top">
                <?php endif; ?>
                <article class="my-3">
                    <?php echo $post->body; ?>

                </article>
                <a href="/" class="text-decoration-none d-block mt-3">Back</a>
            </div>
        </div>
    </div>
    <article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Laravel\article-app\resources\views/show.blade.php ENDPATH**/ ?>