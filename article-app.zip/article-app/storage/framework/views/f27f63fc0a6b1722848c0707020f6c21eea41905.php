
<?php $__env->startSection('container'); ?>
  <!-- ======= Team Section ======= -->
  <section id="team" class="team">
    <div class="container" data-aos="fade-up">

      <div class="section-title">
        <img src="/img/akhi.png" style="max-height: 100px;">
        <h2>Guru Pengajar</h2>
        <img src="/img/ukhti.png" style="max-height: 100px;">
        <h3>Mengenal <span>Guru Pengajar</span></h3>
        <p>Membimbing, mendidik, dan mengajar adalah tugas kami.</p>
      </div>

      <div class="row">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="member">
              <div class="member-img">
                <?php if($user->image): ?>
                  <div style="max-height: 250px; overflow:hidden;">
                    <img src="<?php echo e(asset('img/user-images/' . $user->image)); ?>" class="img-fluid" alt="">
                  </div>
                <?php else: ?>
                  <div style="max-height: 250px; overflow:hidden;">
                    <img src="<?php echo e(asset('img/user-images/' . $image)); ?>" class="img-fluid" alt="">
                  </div>
                <?php endif; ?>
              </div>
              <div class="member-info">
                <h4><?php echo e($user->name); ?></h4>
                <span><?php echo e($user->position); ?></span>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

    </div>
  </section><!-- End Team Section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Laravel\article-app\resources\views/home/users/index.blade.php ENDPATH**/ ?>