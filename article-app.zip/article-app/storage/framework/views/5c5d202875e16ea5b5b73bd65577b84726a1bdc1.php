

<?php $__env->startSection('container'); ?>
    <div class="container">
        <div class="row my-3">
            <div class="col-lg-8">
                <h4 class="mb-3"><?php echo e($registration->title); ?></h4>
                
                <a href="/dashboard/registrations" class="btn btn-success"><span data-feather="arrow-left"></span> Semua Info Registrasi</a>
                <a href="/dashboard/registrations/<?php echo e($registration->slug); ?>/edit" class="btn btn-warning"><span data-feather="edit"></span> Edit</a>
                <form action="/dashboard/registrations/<?php echo e($registration->slug); ?>" method="POST" class="d-inline">
                    <?php echo method_field('delete'); ?>
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-danger" onclick="return confirm('Apakah anda yakin akan menghapus info registrasi <?php echo e($registration->title); ?>?')"><span data-feather="x-circle"></span> Hapus</button>
                </form>
                <?php if($registration->image): ?>
                    <div>
                        <img src="<?php echo e(asset('storage/' . $registration->image)); ?>" class="img-fluid mt-3">
                    </div>
                <?php else: ?>
                    <img src="<?php echo e(asset('storage/registration-images/' . $image)); ?>" class="img-fluid mt-3">
                <?php endif; ?>
                <article class="my-3">
                    <?php echo $registration->body; ?>

                </article>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Laravel\article-app\resources\views/dashboard/registrations/show.blade.php ENDPATH**/ ?>